// API URL base
const API_BASE_URL = 'http://localhost:8000/api';

// Función para obtener todas las dudas
async function fetchDoubts() {
    try {
        const response = await fetch(`${API_BASE_URL}/doubts/`, {
            credentials: 'include'
        });
        if (!response.ok) {
            throw new Error('Error al cargar las dudas');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Función para buscar dudas
async function searchDoubts(query) {
    try {
        const response = await fetch(`${API_BASE_URL}/doubts/search/?query=${encodeURIComponent(query)}`, {
            credentials: 'include'
        });
        if (!response.ok) {
            throw new Error('Error al buscar dudas');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Función para crear una nueva duda
async function createDoubt(doubtData) {
    try {
        const response = await fetch(`${API_BASE_URL}/doubts/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(doubtData),
            credentials: 'include'
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Error al crear la duda');
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Función para actualizar una duda existente
async function updateDoubt(id, doubtData) {
    try {
        const response = await fetch(`${API_BASE_URL}/doubts/${id}/`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(doubtData),
            credentials: 'include'
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Error al actualizar la duda');
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Función para eliminar una duda
async function deleteDoubt(id) {
    try {
        const response = await fetch(`${API_BASE_URL}/doubts/${id}/`, {
            method: 'DELETE',
            credentials: 'include'
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Error al eliminar la duda');
        }
        
        return true;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Función para responder a una duda
async function answerDoubt(id, answer) {
    try {
        const response = await fetch(`${API_BASE_URL}/doubts/${id}/answer/`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ answer }),
            credentials: 'include'
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Error al responder la duda');
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
} 