// API para manejar videos
const API_URL = 'http://localhost:8000/api';

// Funciones para manejar la API de videos
const VideosAPI = {
    // Obtener todos los videos
    async getVideos() {
        try {
            console.log('Obteniendo videos...');
            const response = await fetch(`${API_URL}/videos/`, {
                credentials: 'include'
            });
            console.log('Respuesta:', response);
            if (!response.ok) {
                throw new Error(`Error al obtener videos: ${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            console.log('Datos recibidos:', data);
            return data;
        } catch (error) {
            console.error('Error completo:', error);
            return [];
        }
    },

    // Obtener un video específico por ID
    async getVideo(videoId) {
        try {
            console.log(`Obteniendo video ${videoId}...`);
            const response = await fetch(`${API_URL}/videos/${videoId}/`, {
                credentials: 'include'
            });
            console.log('Respuesta:', response);
            if (!response.ok) {
                throw new Error(`Error al obtener video: ${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            console.log('Datos recibidos:', data);
            return data;
        } catch (error) {
            console.error('Error al obtener video:', error);
            throw error;
        }
    },

    // Buscar videos por título
    async searchVideos(query) {
        try {
            console.log('Buscando videos con query:', query);
            const response = await fetch(`${API_URL}/videos/search/?query=${encodeURIComponent(query)}`, {
                credentials: 'include'
            });
            console.log('Respuesta búsqueda:', response);
            if (!response.ok) {
                throw new Error(`Error al buscar videos: ${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            console.log('Resultados de búsqueda:', data);
            return data;
        } catch (error) {
            console.error('Error en búsqueda:', error);
            return [];
        }
    },

    // Crear un nuevo video
    async createVideo(videoData) {
        try {
            console.log('Creando video con datos:', videoData);
            const response = await fetch(`${API_URL}/videos/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(videoData),
                credentials: 'include'
            });
            console.log('Respuesta creación:', response);
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Error al crear video: ${response.status} ${response.statusText} - ${errorText}`);
            }
            const data = await response.json();
            console.log('Video creado:', data);
            return data;
        } catch (error) {
            console.error('Error completo al crear:', error);
            throw error;
        }
    },

    // Actualizar un video existente
    async updateVideo(videoId, videoData) {
        try {
            console.log(`Actualizando video ${videoId} con datos:`, videoData);
            const response = await fetch(`${API_URL}/videos/${videoId}/`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(videoData),
                credentials: 'include'
            });
            console.log('Respuesta actualización:', response);
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Error al actualizar video: ${response.status} ${response.statusText} - ${errorText}`);
            }
            const data = await response.json();
            console.log('Video actualizado:', data);
            return data;
        } catch (error) {
            console.error('Error completo al actualizar:', error);
            throw error;
        }
    },

    // Eliminar un video
    async deleteVideo(videoId) {
        try {
            console.log(`Eliminando video ${videoId}`);
            const response = await fetch(`${API_URL}/videos/${videoId}/`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            });
            console.log('Respuesta eliminación:', response);
            if (!response.ok) {
                let errorMessage = `Error al eliminar video: ${response.status} ${response.statusText}`;
                try {
                    const errorText = await response.text();
                    if (errorText) {
                        errorMessage += ` - ${errorText}`;
                    }
                } catch (textError) {
                    console.error('No se pudo obtener el texto de error:', textError);
                }
                throw new Error(errorMessage);
            }
            console.log('Video eliminado correctamente');
            return true;
        } catch (error) {
            console.error('Error completo al eliminar:', error);
            throw error;
        }
    }
}; 