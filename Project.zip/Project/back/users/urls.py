from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('check-auth/', views.check_auth, name='check-auth'),
    path('videos/', views.video_list, name='video-list'),
    path('videos/search/', views.search_videos, name='video-search'),
    path('videos/<int:pk>/', views.video_detail, name='video-detail'),
    # URLs para cuestionarios
    path('questionnaires/', views.questionnaire_list, name='questionnaire-list'),
    path('questionnaires/search/', views.search_questionnaires, name='questionnaire-search'),
    path('questionnaires/<int:pk>/', views.questionnaire_detail, name='questionnaire-detail'),
    path('questionnaires/<int:pk>/submit/', views.submit_questionnaire, name='submit-questionnaire'),
    path('user/attempts/', views.user_attempts, name='user-attempts'),
    # URLs para dudas
    path('doubts/', views.doubt_list, name='doubt-list'),
    path('doubts/search/', views.search_doubts, name='doubt-search'),
    path('doubts/<int:pk>/', views.doubt_detail, name='doubt-detail'),
    path('doubts/<int:pk>/answer/', views.answer_doubt, name='answer-doubt'),
    # URLs para evaluaciones
    path('evaluations/', views.evaluation_list, name='evaluation-list'),
    path('evaluations/<int:pk>/', views.evaluation_detail, name='evaluation-detail'),
] 