from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .models import CustomUser, Video, Questionnaire, Question, Option, UserAttempt, Doubt, Evaluation
from .serializers import VideoSerializer, QuestionnaireSerializer, UserAttemptSerializer, QuestionnaireCreateSerializer, DoubtSerializer, EvaluationSerializer
from django.db import transaction
from django.db.models import Avg
import re

# Create your views here.

@api_view(['POST'])
@permission_classes([AllowAny])
def login_view(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    if not username or not password:
        return Response({'error': 'Por favor, ingrese usuario y contraseña'}, 
                      status=status.HTTP_400_BAD_REQUEST)
    
    print(f"Intento de inicio de sesión para usuario: {username}")
    
    user = authenticate(username=username, password=password)
    
    if user is not None:
        print(f"Autenticación exitosa para: {username}")
        
        # Limpiar cualquier sesión existente antes de iniciar una nueva
        if hasattr(request, 'session'):
            request.session.flush()
        
        # Iniciar nueva sesión
        login(request, user)
        
        # Forzar guardar la sesión en la base de datos
        request.session.save()
        
        # Imprimir información de la sesión para depuración
        print(f"Session key después de login: {request.session.session_key}")
        print(f"Session data: {dict(request.session)}")
        
        response = Response({
            'message': 'Inicio de sesión exitoso',
            'username': user.username,
            'user_id': user.id,
            'session_key': request.session.session_key,
            'is_staff': user.is_staff,
            'is_superuser': user.is_superuser
        }, status=status.HTTP_200_OK)
        
        # Configurar cookie de forma más simple para que funcione en desarrollo local
        if request.session.session_key:
            response.set_cookie(
                key='sessionid',
                value=request.session.session_key,
                httponly=True,
                samesite=None,  # Más permisivo para desarrollo
                secure=False,
                max_age=86400,
                domain=None,  # No especificar dominio para que funcione en localhost
                path='/'
            )
            print(f"Cookie de sesión configurada: {request.session.session_key}")
        else:
            print("ERROR: No se pudo obtener una clave de sesión válida")
        
        return response
    else:
        print(f"Autenticación fallida para: {username}")
        return Response({'error': 'Usuario o contraseña incorrectos'}, 
                      status=status.HTTP_401_UNAUTHORIZED)

@api_view(['GET'])
def check_auth(request):
    print("Verificando autenticación para usuario:", 
          request.user.username if request.user.is_authenticated else "No autenticado")
    print("Sesión activa:", bool(request.session.session_key))
    print("Session key:", request.session.session_key)
    print("Cookies recibidas:", request.COOKIES)
    
    status_code = status.HTTP_200_OK  # Siempre devolvemos 200 para evitar problemas CORS
    
    if request.user.is_authenticated:
        response_data = {
            'isAuthenticated': True,
            'username': request.user.username,
            'user_id': request.user.id,
            'session_id': request.session.session_key,
            'is_staff': request.user.is_staff,
            'is_superuser': request.user.is_superuser
        }
    else:
        response_data = {
            'isAuthenticated': False,
            'cookies_received': bool(request.COOKIES),
            'session_key_present': bool(request.session.session_key),
            'debug_info': {
                'cookies': request.COOKIES,
                'session_key': request.session.session_key
            }
        }
    
    return Response(response_data, status=status_code)

@api_view(['POST'])
def logout_view(request):
    print("Ejecutando logout_view")
    print(f"Usuario: {request.user.username if request.user.is_authenticated else 'No autenticado'}")
    print(f"Sesión activa: {bool(request.session.session_key)}")
    print(f"Session key: {request.session.session_key}")
    
    if request.user.is_authenticated:
        username = request.user.username
        logout(request)
        
        # Preparar respuesta
        response = Response({
            'message': f'Sesión cerrada exitosamente para {username}'
        }, status=status.HTTP_200_OK)
        
        # Eliminar la cookie de sesión explícitamente
        response.delete_cookie('sessionid', path='/')
        
        return response
    else:
        # Incluso si no hay usuario autenticado, eliminar las cookies
        response = Response({
            'message': 'No hay sesión activa para cerrar'
        }, status=status.HTTP_200_OK)
        
        # Eliminar la cookie de sesión por si acaso
        response.delete_cookie('sessionid', path='/')
        
        return response

@api_view(['POST'])
@permission_classes([AllowAny])
def register_view(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    if not username or not password:
        return Response({'error': 'Por favor, ingrese usuario y contraseña'}, 
                      status=status.HTTP_400_BAD_REQUEST)
    
    # Validar que el nombre de usuario solo contenga letras y números
    if not re.match(r'^[a-zA-Z0-9]+$', username):
        return Response({'error': 'El usuario solo puede contener letras mayúsculas, minúsculas y números'}, 
                      status=status.HTTP_400_BAD_REQUEST)
    
    if CustomUser.objects.filter(username=username).exists():
        return Response({'error': 'El usuario ya existe'}, 
                      status=status.HTTP_400_BAD_REQUEST)
    
    try:
        user = CustomUser.objects.create_user(username=username, password=password)
        return Response({'message': 'Usuario registrado exitosamente'}, 
                      status=status.HTTP_201_CREATED)
    except Exception as e:
        return Response({'error': str(e)}, 
                      status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
@permission_classes([AllowAny])  # AllowAny para pruebas, en producción cambiar a IsAuthenticated
def video_list(request):
    if request.method == 'GET':
        videos = Video.objects.all().order_by('-created_at')
        serializer = VideoSerializer(videos, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        print(f"Datos recibidos: {request.data}")
        serializer = VideoSerializer(data=request.data)
        if serializer.is_valid():
            video = serializer.save()
            print(f"Video guardado con ID: {video.id}")
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        print(f"Errores de validación: {serializer.errors}")
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([AllowAny])  # AllowAny para pruebas, en producción cambiar a IsAuthenticated
def video_detail(request, pk):
    try:
        video = Video.objects.get(pk=pk)
    except Video.DoesNotExist:
        return Response({'error': 'El video no existe'}, status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = VideoSerializer(video)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = VideoSerializer(video, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        try:
            video.delete()
            return Response({'message': 'Video eliminado correctamente'}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            print(f"Error al eliminar video: {e}")
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([AllowAny])
def search_videos(request):
    query = request.GET.get('query', '')
    if query:
        videos = Video.objects.filter(title__icontains=query)
        serializer = VideoSerializer(videos, many=True)
        return Response(serializer.data)
    else:
        return Response({'error': 'Por favor, proporcione un término de búsqueda'}, 
                      status=status.HTTP_400_BAD_REQUEST)

# Vistas para cuestionarios
@api_view(['GET', 'POST'])
@permission_classes([AllowAny])  # AllowAny para pruebas, en producción cambiar a IsAuthenticated
def questionnaire_list(request):
    if request.method == 'GET':
        questionnaires = Questionnaire.objects.all().order_by('-created_at')
        serializer = QuestionnaireSerializer(questionnaires, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        # Imprimir los datos que recibimos para depurar
        print("Datos recibidos en POST:", request.data)
        
        # Preparar los datos para el serializador
        data = {
            'title': request.data.get('title', ''),
            'questions': []
        }
        
        # Si las preguntas vienen como string JSON, las convertimos a objeto Python
        if 'questions' in request.data and isinstance(request.data['questions'], str):
            import json
            try:
                questions_list = json.loads(request.data['questions'])
                data['questions'] = questions_list  # Asignar la lista ya procesada
            except json.JSONDecodeError as e:
                print("Error al decodificar JSON:", str(e))
                return Response({'error': 'Formato de preguntas inválido'}, status=status.HTTP_400_BAD_REQUEST)
        
        print("Datos procesados:", data)
        serializer = QuestionnaireCreateSerializer(data=data)
        
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    # Crear cuestionario
                    questionnaire = Questionnaire.objects.create(
                        title=serializer.validated_data['title']
                    )
                    
                    # Crear preguntas y opciones
                    for q_data in serializer.validated_data['questions']:
                        question = Question.objects.create(
                            questionnaire=questionnaire,
                            question_text=q_data['question']
                        )
                        
                        # Crear opciones para esta pregunta
                        for i, option_text in enumerate(q_data['options']):
                            correct = str(q_data['correctOption']) == str(i+1)
                            Option.objects.create(
                                question=question,
                                option_text=option_text,
                                is_correct=correct
                            )
                    
                    return Response(QuestionnaireSerializer(questionnaire).data, status=status.HTTP_201_CREATED)
            except Exception as e:
                print("Error al crear cuestionario:", str(e))
                return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            print("Errores de validación:", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([AllowAny])  # AllowAny para pruebas, en producción cambiar a IsAuthenticated
def questionnaire_detail(request, pk):
    try:
        questionnaire = Questionnaire.objects.get(pk=pk)
    except Questionnaire.DoesNotExist:
        return Response({'error': 'El cuestionario no existe'}, status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = QuestionnaireSerializer(questionnaire)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        # Imprimir los datos que recibimos para depurar
        print("Datos recibidos en PUT:", request.data)
        
        # Preparar los datos para el serializador
        data = {
            'title': request.data.get('title', ''),
            'questions': []
        }
        
        # Si las preguntas vienen como string JSON, las convertimos a objeto Python
        if 'questions' in request.data and isinstance(request.data['questions'], str):
            import json
            try:
                questions_list = json.loads(request.data['questions'])
                data['questions'] = questions_list  # Asignar la lista ya procesada
            except json.JSONDecodeError as e:
                print("Error al decodificar JSON:", str(e))
                return Response({'error': 'Formato de preguntas inválido'}, status=status.HTTP_400_BAD_REQUEST)
            
        print("Datos procesados:", data)
        serializer = QuestionnaireCreateSerializer(data=data)
        
        if serializer.is_valid():
            try:
                with transaction.atomic():
                    # Actualizar título del cuestionario
                    questionnaire.title = serializer.validated_data['title']
                    questionnaire.save()
                    
                    # Eliminar preguntas y opciones existentes
                    questionnaire.questions.all().delete()
                    
                    # Crear nuevas preguntas y opciones
                    for q_data in serializer.validated_data['questions']:
                        question = Question.objects.create(
                            questionnaire=questionnaire,
                            question_text=q_data['question']
                        )
                        
                        # Crear opciones para esta pregunta
                        for i, option_text in enumerate(q_data['options']):
                            correct = str(q_data['correctOption']) == str(i+1)
                            Option.objects.create(
                                question=question,
                                option_text=option_text,
                                is_correct=correct
                            )
                    
                    return Response(QuestionnaireSerializer(questionnaire).data)
            except Exception as e:
                print("Error al actualizar cuestionario:", str(e))
                return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            print("Errores de validación:", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        questionnaire.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['POST'])
@permission_classes([AllowAny])  # Cambiado a AllowAny para pruebas
def submit_questionnaire(request, pk):
    try:
        questionnaire = Questionnaire.objects.get(pk=pk)
    except Questionnaire.DoesNotExist:
        return Response({'error': 'El cuestionario no existe'}, status=status.HTTP_404_NOT_FOUND)
    
    # Para pruebas, usar usuario anónimo o el primero disponible
    if request.user.is_authenticated:
        user = request.user
    else:
        # Usar el primer usuario disponible o crear uno para pruebas
        users = CustomUser.objects.all()
        if users.exists():
            user = users.first()
        else:
            # Crear un usuario de prueba si no hay ninguno
            user = CustomUser.objects.create_user(
                username="test_user",
                password="test123"
            )
    
    print(f"Usuario utilizado para el intento: {user.username}")
    
    # Verificar si el usuario ya ha realizado este cuestionario dos veces
    attempts_count = UserAttempt.objects.filter(user=user, questionnaire=questionnaire).count()
    if attempts_count >= 2:
        return Response({'error': 'Has alcanzado el límite de intentos para este cuestionario'}, 
                       status=status.HTTP_400_BAD_REQUEST)
    
    # Procesar las respuestas
    print("Datos recibidos en submit:", request.data)
    
    # Preparar los datos
    user_answers = []
    
    # Si las respuestas vienen como string JSON, las convertimos a objeto Python
    if 'answers' in request.data and isinstance(request.data['answers'], str):
        import json
        try:
            user_answers = json.loads(request.data['answers'])
        except json.JSONDecodeError as e:
            print("Error al decodificar JSON:", str(e))
            return Response({'error': 'Formato de respuestas inválido'}, status=status.HTTP_400_BAD_REQUEST)
    else:
        user_answers = request.data.get('answers', [])
    
    print("Respuestas procesadas:", user_answers)
    correct_answers = 0
    
    for answer in user_answers:
        question_id = answer.get('question_id')
        option_id = answer.get('option_id')
        
        try:
            option = Option.objects.get(id=option_id, question_id=question_id)
            if option.is_correct:
                correct_answers += 1
        except Option.DoesNotExist:
            pass
    
    # Calcular puntuación
    score = 2
    if correct_answers == 1:
        score = 3
    elif correct_answers == 2:
        score = 4
    elif correct_answers == 3:
        score = 5
    
    # Guardar el intento
    attempt = UserAttempt.objects.create(
        user=user,
        questionnaire=questionnaire,
        score=score
    )
    
    return Response({
        'correct_answers': correct_answers,
        'total_questions': 3,
        'score': score,
        'attempts_left': 2 - (attempts_count + 1)
    }, status=status.HTTP_201_CREATED)

@api_view(['GET'])
@permission_classes([AllowAny])  # Cambiado a AllowAny para pruebas
def user_attempts(request):
    # Para pruebas, usar usuario anónimo o el primero disponible
    if request.user.is_authenticated:
        user = request.user
    else:
        # Usar el primer usuario disponible o crear uno para pruebas
        users = CustomUser.objects.all()
        if users.exists():
            user = users.first()
        else:
            # Crear un usuario de prueba si no hay ninguno
            user = CustomUser.objects.create_user(
                username="test_user",
                password="test123"
            )
    
    print(f"Usuario utilizado para obtener intentos: {user.username}")
    attempts = UserAttempt.objects.filter(user=user).order_by('-attempt_date')
    
    # Agrupar por cuestionario y obtener el mejor puntaje
    best_scores = {}
    for attempt in attempts:
        questionnaire_id = attempt.questionnaire.id
        if questionnaire_id not in best_scores or attempt.score > best_scores[questionnaire_id]['score']:
            best_scores[questionnaire_id] = {
                'id': questionnaire_id,
                'title': attempt.questionnaire.title,
                'score': attempt.score,
                'attempts': UserAttempt.objects.filter(user=user, questionnaire=attempt.questionnaire).count()
            }
    
    return Response(list(best_scores.values()))

@api_view(['GET'])
@permission_classes([AllowAny])
def search_questionnaires(request):
    query = request.GET.get('query', '')
    if query:
        questionnaires = Questionnaire.objects.filter(title__icontains=query)
        serializer = QuestionnaireSerializer(questionnaires, many=True)
        return Response(serializer.data)
    else:
        return Response({'error': 'Por favor, proporcione un término de búsqueda'}, 
                      status=status.HTTP_400_BAD_REQUEST)

# Vistas para dudas
@api_view(['GET', 'POST'])
@permission_classes([AllowAny])
def doubt_list(request):
    if request.method == 'GET':
        doubts = Doubt.objects.all().order_by('-created_at')
        serializer = DoubtSerializer(doubts, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        serializer = DoubtSerializer(data=request.data)
        if serializer.is_valid():
            # Asignar el usuario actual si está autenticado
            if request.user.is_authenticated:
                serializer.save(user=request.user)
            else:
                serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([AllowAny])
def doubt_detail(request, pk):
    try:
        doubt = Doubt.objects.get(pk=pk)
    except Doubt.DoesNotExist:
        return Response({'error': 'La duda no existe'}, status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = DoubtSerializer(doubt)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = DoubtSerializer(doubt, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        doubt.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['PUT'])
@permission_classes([AllowAny])  # Permitir a cualquiera responder, en producción usar IsAuthenticated con permisos
def answer_doubt(request, pk):
    try:
        doubt = Doubt.objects.get(pk=pk)
    except Doubt.DoesNotExist:
        return Response({'error': 'La duda no existe'}, status=status.HTTP_404_NOT_FOUND)
    
    answer = request.data.get('answer', '')
    if not answer:
        return Response({'error': 'La respuesta no puede estar vacía'}, status=status.HTTP_400_BAD_REQUEST)
    
    doubt.answer = answer
    doubt.save()
    
    serializer = DoubtSerializer(doubt)
    return Response(serializer.data)

@api_view(['GET'])
@permission_classes([AllowAny])
def search_doubts(request):
    query = request.GET.get('query', '')
    if query:
        doubts = Doubt.objects.filter(title__icontains=query) | Doubt.objects.filter(description__icontains=query)
        serializer = DoubtSerializer(doubts.distinct(), many=True)
        return Response(serializer.data)
    else:
        return Response({'error': 'Por favor, proporcione un término de búsqueda'}, 
                      status=status.HTTP_400_BAD_REQUEST)

# Vistas para evaluaciones
@api_view(['GET', 'POST'])
@permission_classes([AllowAny])
def evaluation_list(request):
    if request.method == 'GET':
        evaluations = Evaluation.objects.all().order_by('-created_at')
        serializer = EvaluationSerializer(evaluations, many=True)
        
        # Calcular promedio
        avg_rating = Evaluation.objects.aggregate(Avg('rating'))['rating__avg']
        count = Evaluation.objects.count()
        
        return Response({
            'evaluations': serializer.data,
            'average': round(avg_rating, 1) if avg_rating else 0,
            'count': count
        })
    
    elif request.method == 'POST':
        serializer = EvaluationSerializer(data=request.data)
        if serializer.is_valid():
            # Asignar el usuario actual si está autenticado
            if request.user.is_authenticated:
                serializer.save(user=request.user)
            else:
                serializer.save()
            
            # Recalcular promedio
            avg_rating = Evaluation.objects.aggregate(Avg('rating'))['rating__avg']
            count = Evaluation.objects.count()
            
            return Response({
                'evaluation': serializer.data,
                'average': round(avg_rating, 1) if avg_rating else 0,
                'count': count
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
@permission_classes([AllowAny])
def evaluation_detail(request, pk):
    try:
        evaluation = Evaluation.objects.get(pk=pk)
    except Evaluation.DoesNotExist:
        return Response({'error': 'La evaluación no existe'}, status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = EvaluationSerializer(evaluation)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        # Versión simplificada para pruebas - no verifica permisos
        serializer = EvaluationSerializer(evaluation, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            
            # Recalcular promedio
            avg_rating = Evaluation.objects.aggregate(Avg('rating'))['rating__avg']
            count = Evaluation.objects.count()
            
            return Response({
                'evaluation': serializer.data,
                'average': round(avg_rating, 1) if avg_rating else 0,
                'count': count
            })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        # Versión simplificada para pruebas - no verifica permisos
        evaluation.delete()
        
        # Recalcular promedio
        avg_rating = Evaluation.objects.aggregate(Avg('rating'))['rating__avg']
        count = Evaluation.objects.count()
        
        return Response({
            'average': round(avg_rating, 1) if avg_rating else 0,
            'count': count
        }, status=status.HTTP_200_OK)
